
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'sofiaclara93',
  applicationName: 'agency-plus',
  appUid: '1qRyN6nJgCPdXWsc7j',
  orgUid: '566b381f-a91e-4967-8104-1653093150be',
  deploymentUid: '9d488da4-8b63-466b-966d-12157382e70d',
  serviceName: 'agency-plus',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.0.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'agency-plus-dev-app', timeout: 6 };

try {
  const userHandler = require('./app.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}